import logo from './logo.svg';
import './App.css';
import { MdEmail } from 'react-icons/md';
import { GiPadlockOpen, GiPadlock } from 'react-icons/gi';
import { useState } from 'react';

function App() {
const [activePassword, setActivePassword] = useState(false)
  return (
    
    <div className="App">
      <div className="Main">
        <div className="Title">
          <h4 className="Title"> Login </h4>


        </div>
        <div className="ContetInputEmail">
       
        <MdEmail size={35} color="#adb5bd"/>
        
        <input className="InputEmail" placeholder="E-mail"/>
        

        </div>

        <div className="ContetInputPassword" onClick={() =>{setActivePassword(false) }}>
          
        {activePassword ?  <GiPadlock size={30} color="gray" />  : null }
          
                <input className="InputPassword" type="Password" placeholder="Password" />
          

        </div>

        
        
        <div className="ButtonLogin">
          

        </div>



 </div>
    </div>
  );
}

export default App;
